plugins { id("com.android.application") }

android {
    namespace = "com.kairnos.gearreroll"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.kairnos.avalon"
        minSdk = 30
        targetSdk = 35
        versionCode = 2
        versionName = "1.0.0"
    }

    // 固定签名：以后每次构建的 APK 签名一致，可以直接覆盖安装升级。
    signingConfigs {
        create("fixed") {
            storeFile = file("fixed.jks")
            storePassword = "android"
            keyAlias = "avalon"
            keyPassword = "android"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("fixed")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    // 离线中文文字识别；截图不会上传到任何服务器。
    implementation("com.google.mlkit:text-recognition-chinese:16.0.1")
}
