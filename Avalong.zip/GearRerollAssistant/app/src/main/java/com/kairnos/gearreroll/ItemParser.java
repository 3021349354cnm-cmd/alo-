package com.kairnos.gearreroll;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** 把文字识别得到的若干行，整理成装备等级、品质、主副词条和按钮位置。纯Java，不依赖安卓。 */
public final class ItemParser {
    private ItemParser() {}

    private static final String[][] ALIAS = {
        {"COST", "成本", "费用", "减费", "花费"},
        {"CRIT_DMG", "暴击伤害", "爆击伤害", "暴伤", "爆伤", "暴击伤"},
        {"CRIT_CHANCE", "暴击机会", "暴击几率", "暴击概率", "暴击率", "爆击机会", "爆击几率", "暴击", "爆击"},
        {"MELEE", "近战伤害", "近战攻击", "近战"},
        {"RANGED", "远程伤害", "远程攻击", "远程"},
        {"HP", "生命值", "最大生命", "生命", "血量"},
        {"COOLDOWN", "冷却", "准备时间", "准备"},
        {"AGILITY", "敏捷"},
        {"CHARISMA", "魅力"},
        {"VALOR", "勇气"},
        {"RANGE", "射程", "射击距离", "射击范围"},
    };

    private static final String[] EXCLUDE = {
        "等级", "升级", "经验", "套装", "效果", "传奇", "史诗", "稀有", "普通", "重掷", "继续", "返回",
        "回收", "融合", "出售", "锁定", "装备", "需要", "消耗", "代币", "金币", "数量", "点击", "确认", "取消"
    };

    private static final String[] WARN = {"不足", "购买", "充值", "网络", "断开", "超时", "已达上限"};

    private static final Pattern NUM = Pattern.compile("([0-9]+(?:[.,][0-9]+)?)");
    private static final Pattern LEVEL = Pattern.compile("(?:等级|Lv\\.?|LV\\.?|Level)[:：]?([0-9lI|!OoZ]{1,2})");
    private static final Pattern LEVEL2 = Pattern.compile("([0-9]{1,2})级");

    private static final class Entry {
        final int idx; final OcrLine line; final String s;
        String fam; double value = Double.NaN; boolean hasPct; Stat stat;
        Entry(int idx, OcrLine line, String s) { this.idx = idx; this.line = line; this.s = s; }
    }

    // ---------- 工具 ----------

    public static String norm(String t) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (Character.isWhitespace(c) || c == '\u3000' || c == '\u00a0') continue;
            int d = Character.digit(c, 10);
            if (d >= 0 && c > '9') { sb.append((char) ('0' + d)); continue; }
            switch (c) {
                case '％': c = '%'; break;
                case '＋': c = '+'; break;
                case '－': case '—': case '–': case '−': c = '-'; break;
                case '：': c = ':'; break;
                case '（': c = '('; break;
                case '）': c = ')'; break;
                case '．': c = '.'; break;
                case '，': c = ','; break;
                default: break;
            }
            sb.append(c);
        }
        return sb.toString();
    }

    private static String core(String s) {
        return s.replaceAll("[0-9.,+\\-%xX×:/()\\[\\]~～*=]", "");
    }

    private static int cjkCount(String s) {
        int n = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '\u4e00' && c <= '\u9fff') n++;
        }
        return n;
    }

    private static boolean hasDigit(String s) {
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) >= '0' && s.charAt(i) <= '9') return true;
        return false;
    }

    private static String matchFamily(String core) {
        if (core.isEmpty()) return null;
        for (String[] row : ALIAS) {
            for (int i = 1; i < row.length; i++) {
                String a = row[i];
                if (core.contains(a) && core.length() <= a.length() + 4) return row[0];
            }
        }
        return null;
    }

    private static boolean isExcluded(String s) {
        for (String k : EXCLUDE) if (s.contains(k)) return true;
        return false;
    }

    private static double parseNum(String t) {
        try { return Double.parseDouble(t.replace(',', '.')); } catch (Exception e) { return Double.NaN; }
    }

    private static Stat resolve(String fam, boolean pct) {
        switch (fam) {
            case "COST": return Stat.COST;
            case "CRIT_DMG": return Stat.CRIT_DMG;
            case "CRIT_CHANCE": return Stat.CRIT_CHANCE;
            case "COOLDOWN": return Stat.COOLDOWN;
            case "AGILITY": return Stat.AGILITY;
            case "CHARISMA": return Stat.CHARISMA;
            case "VALOR": return Stat.VALOR;
            case "RANGE": return Stat.RANGE;
            case "MELEE": return pct ? Stat.MELEE_PCT : Stat.MELEE_FLAT;
            case "RANGED": return pct ? Stat.RANGED_PCT : Stat.RANGED_FLAT;
            case "HP": return pct ? Stat.HP_PCT : Stat.HP_FLAT;
            default: return null;
        }
    }

    private static OcrLine findButton(List<OcrLine> lines, List<String> norm, String[] aliases) {
        OcrLine best = null;
        for (int i = 0; i < lines.size(); i++) {
            String s = norm.get(i);
            boolean ok = false;
            for (String a : aliases) {
                if (s.contains(a) && core(s).length() <= a.length() + 2) { ok = true; break; }
            }
            if (!ok) continue;
            OcrLine l = lines.get(i);
            if (best == null || l.cy() > best.cy()) best = l;
        }
        return best;
    }

    private static String clean(String s) { return s.replaceAll("[^0-9a-zA-Z\u4e00-\u9fff]", ""); }

    // ---------- 主入口 ----------

    public static ScreenRead parse(List<OcrLine> lines, int screenW, int screenH) {
        ScreenRead r = new ScreenRead();
        r.lineCount = lines.size();
        List<String> norm = new ArrayList<>();
        StringBuilder all = new StringBuilder();
        for (OcrLine l : lines) { norm.add(norm(l.text)); all.append(l.text).append('\n'); }
        r.text = all.toString();
        String joined = String.join("\n", norm);

        // 按钮
        r.btnContinue = findButton(lines, norm, new String[]{"继续"});
        r.btnBack = findButton(lines, norm, new String[]{"返回"});
        r.btnReroll = findButton(lines, norm, new String[]{"重掷", "重置", "重新掷", "重投"});

        // 标记词
        if (joined.contains("已装备") || joined.contains("装备中") || joined.contains("已锁定") || joined.contains("已上锁")) r.lockedWord = true;
        for (String w : WARN) if (joined.contains(w)) { r.warnWord = w; break; }
        for (GearData.SetDef sd : GearData.SETS) {
            if (sd.confirmed && joined.contains(sd.zh)) r.setNamesFound.add(sd.zh);
        }

        // 品质
        boolean leg = joined.contains("传奇") || joined.contains("Legendary") || joined.contains("LEGENDARY");
        boolean epi = joined.contains("史诗") || joined.contains("Epic") || joined.contains("EPIC");
        if (leg && epi) r.qualityConflict = true;
        else if (leg) r.quality = ScreenRead.Quality.LEGENDARY;
        else if (epi) r.quality = ScreenRead.Quality.EPIC;
        else if (joined.contains("稀有") || joined.contains("Rare")) r.quality = ScreenRead.Quality.RARE;
        else if (joined.contains("普通") || joined.contains("Common")) r.quality = ScreenRead.Quality.COMMON;

        parseLevel(r, lines, norm);

        // 词条行
        boolean[] consumed = new boolean[lines.size()];
        List<Entry> rec = new ArrayList<>();
        List<Entry> unknown = new ArrayList<>();
        for (int i = 0; i < lines.size(); i++) {
            String s = norm.get(i);
            if (s.isEmpty() || consumed[i]) continue;
            String fam = matchFamily(core(s));
            if (fam == null) continue;
            Entry e = new Entry(i, lines.get(i), s);
            e.fam = fam;
            Matcher m = NUM.matcher(s);
            if (m.find()) { e.value = parseNum(m.group(1)); e.hasPct = s.indexOf('%') >= 0; }
            else {
                int j = neighborValue(e, lines, norm, consumed);
                if (j >= 0) {
                    consumed[j] = true;
                    Matcher m2 = NUM.matcher(norm.get(j));
                    if (m2.find()) e.value = parseNum(m2.group(1));
                    e.hasPct = norm.get(j).indexOf('%') >= 0;
                }
            }
            if (Double.isNaN(e.value)) { unknown.add(e); continue; }
            boolean needsPct = e.fam.equals("HP") || e.fam.equals("MELEE") || e.fam.equals("RANGED");
            boolean pct = e.hasPct || (needsPct && e.value < 15);
            e.stat = resolve(e.fam, pct);
            if (e.stat != null) rec.add(e); else unknown.add(e);
        }
        if (rec.isEmpty()) return r;

        double[] hs = new double[rec.size()];
        for (int i = 0; i < rec.size(); i++) hs[i] = rec.get(i).line.h();
        java.util.Arrays.sort(hs);
        final double medH = hs[hs.length / 2];

        Collections.sort(rec, new Comparator<Entry>() {
            @Override public int compare(Entry a, Entry b) {
                long ra = Math.round(a.line.cy() / (0.6 * medH));
                long rb = Math.round(b.line.cy() / (0.6 * medH));
                if (ra != rb) return ra < rb ? -1 : 1;
                return Integer.compare(a.line.cx(), b.line.cx());
            }
        });

        // 切成若干组，取词条最多的一组
        List<List<Entry>> clusters = new ArrayList<>();
        List<Entry> cur = new ArrayList<>();
        cur.add(rec.get(0));
        for (int i = 1; i < rec.size(); i++) {
            if (rec.get(i).line.cy() - rec.get(i - 1).line.cy() <= 3.2 * medH) cur.add(rec.get(i));
            else { clusters.add(cur); cur = new ArrayList<>(); cur.add(rec.get(i)); }
        }
        clusters.add(cur);
        int bestIdx = 0;
        for (int i = 1; i < clusters.size(); i++) if (clusters.get(i).size() > clusters.get(bestIdx).size()) bestIdx = i;
        List<Entry> best = new ArrayList<>(clusters.get(bestIdx));
        // 主词条如果单独显示在上方，把它并进来
        if (bestIdx > 0 && best.size() >= 2) {
            List<Entry> prev = clusters.get(bestIdx - 1);
            if (prev.size() == 1 && best.get(0).line.cy() - prev.get(0).line.cy() <= 7 * medH) best.add(0, prev.get(0));
        }

        double firstCy = best.get(0).line.cy();
        double lastCy = best.get(best.size() - 1).line.cy();
        int[] ls = new int[best.size()];
        for (int i = 0; i < best.size(); i++) ls[i] = best.get(i).line.l;
        java.util.Arrays.sort(ls);
        int medL = ls[ls.length / 2];

        r.main = best.get(0).stat;
        for (int i = 1; i < best.size(); i++) r.subs.add(best.get(i).stat);

        // 读不出名字但像词条的行：算“未识别词条”
        List<Entry> extra = new ArrayList<>(unknown);
        for (int i = 0; i < lines.size(); i++) {
            if (consumed[i]) continue;
            String s = norm.get(i);
            if (s.isEmpty() || isExcluded(s)) continue;
            boolean already = false;
            for (Entry e : rec) if (e.idx == i) { already = true; break; }
            for (Entry e : unknown) if (e.idx == i) { already = true; break; }
            if (already) continue;
            if (cjkCount(s) >= 2 && hasDigit(s)) extra.add(new Entry(i, lines.get(i), s));
        }
        for (Entry e : extra) {
            if (isExcluded(e.s)) continue;
            int cy = e.line.cy();
            if (cy < firstCy - 1.6 * medH || cy > lastCy + 1.8 * medH) continue;
            if (Math.abs(e.line.l - medL) > 0.15 * screenW) continue;
            if (cy < firstCy - 0.5 * medH) r.mainUnknown = true;
            else { r.unknownSubs++; r.unknownTexts.add(e.line.text); }
        }
        return r;
    }

    private static int neighborValue(Entry e, List<OcrLine> lines, List<String> norm, boolean[] consumed) {
        int bestJ = -1;
        double bestDx = Double.MAX_VALUE;
        for (int j = 0; j < lines.size(); j++) {
            if (j == e.idx || consumed[j]) continue;
            String t = norm.get(j);
            if (!hasDigit(t) || !core(t).isEmpty()) continue;
            OcrLine lj = lines.get(j);
            double tol = 0.7 * Math.max(e.line.h(), lj.h());
            if (Math.abs(lj.cy() - e.line.cy()) > tol) continue;
            if (lj.cx() <= e.line.cx()) continue;
            double dx = Math.abs(lj.l - e.line.r);
            if (dx < bestDx) { bestDx = dx; bestJ = j; }
        }
        return bestJ;
    }

    private static int mapLevelToken(String tok) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < tok.length(); i++) {
            char c = tok.charAt(i);
            if (c == 'l' || c == 'I' || c == '|' || c == '!') c = '1';
            else if (c == 'O' || c == 'o') c = '0';
            else if (c == 'Z') c = '2';
            if (c < '0' || c > '9') return -1;
            sb.append(c);
        }
        if (sb.length() == 0) return -1;
        try { return Integer.parseInt(sb.toString()); } catch (Exception e) { return -1; }
    }

    private static void parseLevel(ScreenRead r, List<OcrLine> lines, List<String> norm) {
        for (int i = 0; i < norm.size(); i++) {
            String s = norm.get(i);
            if (s.contains("Max") || s.contains("MAX") || s.contains("满级")) r.maxLevel = true;
        }
        for (int i = 0; i < norm.size(); i++) {
            Matcher m = LEVEL.matcher(norm.get(i));
            if (m.find()) {
                int v = mapLevelToken(m.group(1));
                if (v >= 0) { r.level = v; if (v >= 12) r.maxLevel = true; return; }
            }
        }
        // “等级”和数字被拆成两行
        for (int i = 0; i < norm.size(); i++) {
            String s = norm.get(i);
            if (!s.endsWith("等级") && !s.equals("等级")) continue;
            OcrLine a = lines.get(i);
            int bestJ = -1; double bestDx = Double.MAX_VALUE;
            for (int j = 0; j < lines.size(); j++) {
                if (j == i) continue;
                String t = norm.get(j).replace("Max", "").replace("MAX", "");
                if (t.isEmpty() || t.length() > 3) continue;
                int v = mapLevelToken(t);
                if (v < 0) continue;
                OcrLine b = lines.get(j);
                if (Math.abs(b.cy() - a.cy()) > 0.7 * Math.max(a.h(), b.h())) continue;
                if (b.cx() <= a.cx()) continue;
                double dx = Math.abs(b.l - a.r);
                if (dx < bestDx) { bestDx = dx; bestJ = j; }
            }
            if (bestJ >= 0) {
                int v = mapLevelToken(norm.get(bestJ).replace("Max", "").replace("MAX", ""));
                r.level = v; if (v >= 12) r.maxLevel = true; return;
            }
        }
        for (int i = 0; i < norm.size(); i++) {
            Matcher m = LEVEL2.matcher(norm.get(i));
            if (m.find() && !norm.get(i).contains("升级")) {
                int v = Integer.parseInt(m.group(1));
                r.level = v; if (v >= 12) r.maxLevel = true; return;
            }
        }
    }
}
