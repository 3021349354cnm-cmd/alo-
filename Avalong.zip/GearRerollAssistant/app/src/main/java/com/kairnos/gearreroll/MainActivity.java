package com.kairnos.gearreroll;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.view.MotionEvent;
import android.view.animation.DecelerateInterpolator;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {
    private static final int INK = Color.rgb(28, 28, 30);
    private static final int MUTED = Color.rgb(110, 112, 122);
    private static final int ACCENT = Color.rgb(0, 122, 255);
    private int cardIndex = 0;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private int setIdx;
    private RuleConfig rule;
    private LinearLayout ruleBox;
    private TextView stateText, permText, calText, logView, catalogView;
    private final List<String> appPkgs = new ArrayList<>();

    private final Runnable refresher = new Runnable() {
        @Override public void run() {
            refresh();
            handler.postDelayed(this, 800);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setIdx = Cfg.setIndex(this);
        rule = Cfg.loadRule(this, setIdx);
        buildUi();
    }

    @Override protected void onResume() {
        super.onResume();
        handler.removeCallbacks(refresher);
        handler.post(refresher);
    }

    @Override protected void onPause() {
        super.onPause();
        handler.removeCallbacks(refresher);
    }

    // ================= 界面搭建 =================

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(22), dp(18), dp(30));
        GradientDrawable pageBg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{Color.rgb(205, 222, 247), Color.rgb(233, 226, 247), Color.rgb(247, 232, 238)});
        page.setBackground(pageBg);
        scroll.addView(page);

        TextView eyebrow = text("死亡突围 · 装备自动重掷", 12, MUTED, false);
        page.addView(eyebrow);
        TextView title = text("Avalon", 38, INK, true);
        LinearLayout.LayoutParams tlp = lp(-2, -2);
        tlp.topMargin = dp(4);
        page.addView(title, tlp);

        // 状态卡
        LinearLayout st = card(page, null);
        stateText = text("未启动", 19, INK, true);
        st.addView(stateText);
        permText = text("", 12, MUTED, false);
        st.addView(permText, topMargin(6));
        calText = text("", 12, MUTED, false);
        st.addView(calText, topMargin(3));
        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        st.addView(row1, topMargin(12));
        row1.addView(button("打开无障碍设置", new View.OnClickListener() {
            @Override public void onClick(View v) { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
        }), weight());
        row1.addView(button("显示悬浮控制条", new View.OnClickListener() {
            @Override public void onClick(View v) {
                GearAutomationService s = GearAutomationService.instance;
                if (s == null) toast("请先在无障碍设置里开启 Avalon");
                else { s.showPanel(); toast("悬浮控制条已显示，切到游戏即可看到"); }
            }
        }), weight());
        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        st.addView(row2, topMargin(8));
        row2.addView(button("打开游戏", new View.OnClickListener() {
            @Override public void onClick(View v) { openGame(); }
        }), weight());
        row2.addView(button("查看全部套装", new View.OnClickListener() {
            @Override public void onClick(View v) {
                catalogView.setVisibility(catalogView.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
            }
        }), weight());
        catalogView = text(buildCatalog(), 12, INK, false);
        catalogView.setVisibility(View.GONE);
        catalogView.setTextIsSelectable(true);
        st.addView(catalogView, topMargin(10));

        // 01 目标游戏
        LinearLayout c1 = section(page, "01 / 目标游戏", "只在选中的游戏在前台时才会点击；选“不限定”则不检查。");
        Spinner appSpinner = new Spinner(this);
        populateApps(appSpinner);
        c1.addView(appSpinner, lp(-1, 48));

        // 02 套装
        LinearLayout c2 = section(page, "02 / 要刷的套装", "在游戏底部切到同一个套装，再点开始。");
        Spinner setSpinner = new Spinner(this);
        ArrayAdapter<String> sa = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, GearData.displayNames());
        setSpinner.setAdapter(sa);
        setSpinner.setSelection(setIdx, false);
        setSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                if (pos == setIdx) return;
                setIdx = pos;
                Cfg.setSetIndex(MainActivity.this, pos);
                rule = Cfg.loadRule(MainActivity.this, pos);
                rebuildRule();
            }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });
        c2.addView(setSpinner, lp(-1, 48));

        // 03 筛选规则
        ruleBox = section(page, "03 / 词条筛选", "勾选“想要”的副词条；“必带”缺一个就算垃圾。");
        rebuildRule();

        // 04 运行设置
        LinearLayout c4 = section(page, "04 / 运行设置", "格子数按你游戏里一屏能看到的装备数填写。");
        LinearLayout nums = new LinearLayout(this);
        nums.setOrientation(LinearLayout.HORIZONTAL);
        nums.addView(labeled("每行几个", numField("columns", 4)), weight());
        nums.addView(labeled("一屏几行", numField("rows", 3)), weight());
        c4.addView(nums);
        LinearLayout nums2 = new LinearLayout(this);
        nums2.setOrientation(LinearLayout.HORIZONTAL);
        nums2.addView(labeled("翻页距离 %", numField("scroll_pct", 100)), weight());
        nums2.addView(labeled("最多重掷次数(0=不限)", numField("max_rolls", 0)), weight());
        c4.addView(nums2, topMargin(8));
        c4.addView(check("一屏处理完后自动上滑翻页", Cfg.autoScroll(this), new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) { Cfg.putBool(MainActivity.this, "auto_scroll", on); }
        }), topMargin(6));
        c4.addView(check("校验套装名（读到的套装名和所选不符就暂停）", Cfg.verifySet(this), new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) { Cfg.putBool(MainActivity.this, "verify_set", on); }
        }), topMargin(2));

        // 05 校准与安全
        LinearLayout c5 = section(page, "05 / 校准与安全", "进游戏点开一件1级装备，点悬浮条“校准”，按提示点4个位置。");
        c5.addView(check("我已人工确认：本页待刷装备都没上锁、没装备、不是金星装备", Cfg.safeAck(this), new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) { Cfg.putBool(MainActivity.this, "safe_ack", on); }
        }));
        c5.addView(text("程序只重掷“等级读到恰好是1”的装备；读不出等级、读不出词条或词条行数不对时会暂停，不会乱点。锁和金星图标认不出来，所以需要你先排除。", 12, MUTED, false), topMargin(6));

        // 06 日志
        LinearLayout c6 = section(page, "06 / 运行日志", "悬浮条的“测试”按钮可以看到屏幕识别到的全部文字。");
        logView = text("", 12, INK, false);
        logView.setTypeface(Typeface.MONOSPACE);
        c6.addView(logView);

        setContentView(scroll);
    }

    /** 根据当前套装重建筛选规则区域。 */
    private void rebuildRule() {
        while (ruleBox.getChildCount() > 2) ruleBox.removeViewAt(2);   // 保留 section() 加的标题和副标题
        final GearData.SetDef d = GearData.SETS[setIdx];
        TextView info = text(d.zh + "（" + d.en + "）  品质：" + d.tier + "\n套装效果：" + d.bonus
            + "\n默认词条来源：" + d.source + (d.confirmed ? "" : "\n* 这个套装的中文名是按英文翻译的，游戏里可能叫法不同；不影响刷装备，只影响“校验套装名”。"),
            12, MUTED, false);
        ruleBox.addView(info);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.addView(text("副词条", 12, MUTED, true), weight());
        head.addView(text("想要", 12, MUTED, true), fixed(64));
        head.addView(text("必带", 12, MUTED, true), fixed(64));
        ruleBox.addView(head, topMargin(12));

        for (final Stat s : Stat.values()) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.addView(text(s.label, 14, INK, false), weight());
            CheckBox want = new CheckBox(this);
            want.setButtonTintList(ColorStateList.valueOf(ACCENT));
            want.setChecked((rule.wanted & s.bit()) != 0);
            CheckBox must = new CheckBox(this);
            must.setButtonTintList(ColorStateList.valueOf(ACCENT));
            must.setChecked((rule.must & s.bit()) != 0);
            want.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                    rule.wanted = on ? (rule.wanted | s.bit()) : (rule.wanted & ~s.bit());
                    saveRule();
                }
            });
            must.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                    rule.must = on ? (rule.must | s.bit()) : (rule.must & ~s.bit());
                    saveRule();
                }
            });
            row.addView(want, fixed(64));
            row.addView(must, fixed(64));
            ruleBox.addView(row);
        }

        // 至少命中 / 品质
        LinearLayout opts = new LinearLayout(this);
        opts.setOrientation(LinearLayout.HORIZONTAL);
        Spinner hits = new Spinner(this);
        hits.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{"至少命中 1 条", "至少命中 2 条", "至少命中 3 条", "至少命中 4 条"}));
        hits.setSelection(Math.max(0, Math.min(3, rule.minHits - 1)), false);
        hits.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                if (rule.minHits != pos + 1) { rule.minHits = pos + 1; saveRule(); }
            }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });
        Spinner qual = new Spinner(this);
        qual.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{"只刷传奇(金)", "只刷史诗(紫)", "自动识别品质"}));
        qual.setSelection(Math.max(0, Math.min(2, rule.qualityMode)), false);
        qual.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                if (rule.qualityMode != pos) { rule.qualityMode = pos; saveRule(); }
            }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });
        opts.addView(hits, weight());
        opts.addView(qual, weight());
        ruleBox.addView(opts, topMargin(10));

        ruleBox.addView(check("主副词条、副词条之间重复 → 直接淘汰", rule.rejectDuplicate, new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) { rule.rejectDuplicate = on; saveRule(); }
        }));
        ruleBox.addView(check("近战系与远程系同时出现 → 直接淘汰（绅士）", rule.exclusiveMeleeRanged, new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) { rule.exclusiveMeleeRanged = on; saveRule(); }
        }));

        // 主词条要求
        ruleBox.addView(text("主词条要求（全勾 = 不限制；杯子主词条固定为生命值）", 12, MUTED, true), topMargin(12));
        ruleBox.addView(mainRow("表", Stat.COOLDOWN, Stat.AGILITY), topMargin(2));
        ruleBox.addView(mainRow("书", Stat.CRIT_CHANCE, Stat.CRIT_DMG, Stat.HP_PCT, Stat.MELEE_PCT, Stat.RANGED_PCT));
        ruleBox.addView(mainRow("刀", Stat.MELEE_FLAT, Stat.RANGED_FLAT));

        ruleBox.addView(button("恢复本套装的推荐设置", new View.OnClickListener() {
            @Override public void onClick(View v) {
                int keepQuality = rule.qualityMode;
                Cfg.resetRule(MainActivity.this, setIdx);
                rule = Cfg.loadRule(MainActivity.this, setIdx);
                rule.qualityMode = keepQuality;
                rebuildRule();
                toast("已恢复");
            }
        }), topMargin(12));
    }

    private LinearLayout mainRow(String slotName, final Stat... options) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(text(slotName, 13, INK, true), topMargin(6));
        final String slot = slotName;
        for (final Stat s : options) {
            CheckBox cb = new CheckBox(this);
            cb.setText(s.label);
            cb.setButtonTintList(ColorStateList.valueOf(ACCENT));
            cb.setChecked((maskOf(slot) & s.bit()) != 0);
            cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                    int m = maskOf(slot);
                    int nm = on ? (m | s.bit()) : (m & ~s.bit());
                    if (nm == 0) { b.setChecked(true); toast("至少保留一个主词条"); return; }
                    setMask(slot, nm);
                    saveRule();
                }
            });
            box.addView(cb);
        }
        return box;
    }

    private int maskOf(String slot) {
        if (slot.equals("表")) return rule.watchMain;
        if (slot.equals("书")) return rule.bookMain;
        return rule.knifeMain;
    }

    private void setMask(String slot, int m) {
        if (slot.equals("表")) rule.watchMain = m;
        else if (slot.equals("书")) rule.bookMain = m;
        else rule.knifeMain = m;
    }

    private void saveRule() { Cfg.saveRule(this, setIdx, rule); }

    private String buildCatalog() {
        StringBuilder sb = new StringBuilder();
        sb.append("全部金色传奇套装 + 建筑工、战术（3 件同套装生效）。词条池是默认推荐，可在下方自己改。\n* 译名未核对\n");
        for (GearData.SetDef d : GearData.SETS) {
            sb.append("\n【").append(d.zh).append(d.confirmed ? "" : "*").append("】").append(d.en).append("  ").append(d.tier)
              .append("\n  效果：").append(d.bonus)
              .append("\n  推荐副词条：").append(Stat.names(d.wanted));
            if (d.must != 0) sb.append("\n  必带：").append(Stat.names(d.must));
        }
        return sb.toString();
    }

    // ================= 状态刷新 =================

    private boolean serviceEnabled() {
        String s = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return s != null && s.contains(getPackageName()) && s.contains("GearAutomationService");
    }

    private void refresh() {
        boolean on = serviceEnabled();
        boolean conn = GearAutomationService.instance != null;
        permText.setText("无障碍服务：" + (on ? (conn ? "已开启并连接" : "已开启（连接中）") : "未开启，点上方按钮去开启"));
        calText.setText("位置校准：" + (Cfg.calibrated(this) ? "已完成" : "未完成（进游戏点悬浮条“校准”）"));
        stateText.setText(conn ? GearAutomationService.stateText : "未启动");
        String lg = GearAutomationService.recentLog(30);
        logView.setText(lg.isEmpty() ? "（暂无）" : lg);
    }

    private void openGame() {
        String pkg = Cfg.targetPackage(this);
        if (pkg.isEmpty()) { toast("先在“目标游戏”里选一个"); return; }
        Intent li = getPackageManager().getLaunchIntentForPackage(pkg);
        if (li == null) { toast("打不开这个应用"); return; }
        GearAutomationService s = GearAutomationService.instance;
        if (s != null) s.showPanel();
        startActivity(li);
    }

    private void populateApps(final Spinner spinner) {
        PackageManager pm = getPackageManager();
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(i, 0);
        final List<String[]> items = new ArrayList<>();
        for (ResolveInfo ri : list) {
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(getPackageName())) continue;
            items.add(new String[]{String.valueOf(ri.loadLabel(pm)), pkg});
        }
        Collections.sort(items, new Comparator<String[]>() {
            @Override public int compare(String[] a, String[] b) { return a[0].compareToIgnoreCase(b[0]); }
        });
        List<String> names = new ArrayList<>();
        appPkgs.clear();
        names.add("（不限定应用）");
        appPkgs.add("");
        for (String[] it : items) { names.add(it[0]); appPkgs.add(it[1]); }
        spinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names));
        String saved = Cfg.targetPackage(this);
        int sel = appPkgs.indexOf(saved);
        if (sel < 0) {
            for (int k = 1; k < names.size(); k++) {
                String n = names.get(k);
                if (n.contains("死亡突围") || n.contains("僵尸战争")) { sel = k; break; }
            }
            if (sel >= 0) Cfg.setTargetPackage(this, appPkgs.get(sel));
        }
        if (sel < 0) sel = 0;
        spinner.setSelection(sel, false);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                if (pos >= 0 && pos < appPkgs.size()) Cfg.setTargetPackage(MainActivity.this, appPkgs.get(pos));
            }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });
    }

    // ================= 小工具 =================

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        return t;
    }

    private LinearLayout.LayoutParams lp(int w, int hDp) {
        return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), hDp < 0 ? hDp : dp(hDp));
    }

    private LinearLayout.LayoutParams topMargin(int dpTop) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(dpTop);
        return p;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        p.leftMargin = dp(3);
        p.rightMargin = dp(3);
        return p;
    }

    private LinearLayout.LayoutParams fixed(int wDp) {
        return new LinearLayout.LayoutParams(dp(wDp), LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout card(LinearLayout parent, String unused) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(18), dp(16), dp(18), dp(18));
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{Color.argb(235, 255, 255, 255), Color.argb(190, 255, 255, 255)});
        g.setCornerRadius(dp(26));
        g.setStroke(dp(1), Color.argb(200, 255, 255, 255));
        c.setBackground(g);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(14);
        parent.addView(c, p);
        c.setAlpha(0f);
        c.setTranslationY(dp(18));
        c.animate().alpha(1f).translationY(0f).setDuration(420).setStartDelay(60L * (cardIndex++))
            .setInterpolator(new DecelerateInterpolator(1.6f)).start();
        return c;
    }

    private LinearLayout section(LinearLayout parent, String title, String sub) {
        LinearLayout c = card(parent, null);
        c.addView(text(title, 15, INK, true));
        c.addView(text(sub, 12, MUTED, false), topMargin(2));
        return c;
    }

    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{Color.rgb(64, 156, 255), Color.rgb(0, 122, 255)});
        g.setCornerRadius(dp(22));
        b.setBackground(g);
        b.setOnClickListener(l);
        b.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                int a = e.getAction();
                if (a == MotionEvent.ACTION_DOWN) v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(110).start();
                else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) v.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(new DecelerateInterpolator()).start();
                return false;
            }
        });
        return b;
    }

    private CheckBox check(String label, boolean on, CompoundButton.OnCheckedChangeListener l) {
        CheckBox c = new CheckBox(this);
        c.setText(label);
        c.setTextSize(13);
        c.setTextColor(INK);
        c.setChecked(on);
        c.setButtonTintList(ColorStateList.valueOf(ACCENT));
        c.setOnCheckedChangeListener(l);
        return c;
    }

    private LinearLayout labeled(String label, View field) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(3), 0, dp(3), 0);
        box.addView(text(label, 11, MUTED, false));
        box.addView(field, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return box;
    }

    private EditText numField(final String key, int def) {
        final EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setSingleLine(true);
        e.setText(String.valueOf(Cfg.sp(this).getInt(key, def)));
        e.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) {
                try { Cfg.putInt(MainActivity.this, key, Integer.parseInt(s.toString().trim())); } catch (Exception ex) { }
            }
        });
        return e;
    }
}
