package com.kairnos.gearreroll;

/** 一行识别出来的文字及其在屏幕上的位置（像素）。 */
public final class OcrLine {
    public final String text;
    public final int l, t, r, b;

    public OcrLine(String text, int l, int t, int r, int b) {
        this.text = text; this.l = l; this.t = t; this.r = r; this.b = b;
    }
    public int cx() { return (l + r) / 2; }
    public int cy() { return (t + b) / 2; }
    public int h() { return Math.max(1, b - t); }
    public int w() { return Math.max(1, r - l); }
    @Override public String toString() { return text + "@" + cx() + "," + cy(); }
}
