package com.kairnos.gearreroll;

/** 规则判定结果。 */
public final class Verdict {
    public enum Kind { KEEP, REJECT, UNKNOWN }
    public final Kind kind;
    public final String reason;
    public final int hits;
    public Verdict(Kind kind, String reason, int hits) { this.kind = kind; this.reason = reason; this.hits = hits; }
}
