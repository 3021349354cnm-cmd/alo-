package com.kairnos.gearreroll;

import java.util.ArrayList;
import java.util.List;

/** 全部金色传奇套装 + 建筑工、战术（来源：Dead Ahead 维基 2026-10 版）与默认筛选推荐。纯数据，不依赖安卓。 */
public final class GearData {
    private GearData() {}

    public static final class SetDef {
        public final String zh, en, tier, bonus, source;
        public final boolean confirmed;
        public int wanted, must;
        public boolean exclusive, epic;
        public int watch = Stat.mask(Stat.COOLDOWN, Stat.AGILITY);
        public int book = Stat.mask(Stat.CRIT_CHANCE, Stat.CRIT_DMG, Stat.HP_PCT, Stat.MELEE_PCT, Stat.RANGED_PCT);
        public int knife = Stat.mask(Stat.MELEE_FLAT, Stat.RANGED_FLAT);
        public int cup = Stat.mask(Stat.HP_FLAT);

        SetDef(String zh, String en, boolean confirmed, String tier, String bonus, int wanted, String source) {
            this.zh = zh; this.en = en; this.confirmed = confirmed; this.tier = tier;
            this.bonus = bonus; this.wanted = wanted; this.source = source;
        }

        public String displayName() { return zh + (confirmed ? "" : "*") + " · " + en; }
    }

    private static final int RANGED = Stat.mask(Stat.RANGED_FLAT, Stat.RANGED_PCT, Stat.CRIT_DMG, Stat.CRIT_CHANCE, Stat.RANGE, Stat.COST);
    private static final int MELEE = Stat.mask(Stat.MELEE_FLAT, Stat.MELEE_PCT, Stat.CRIT_DMG, Stat.CRIT_CHANCE, Stat.COST);
    private static final int TANK = Stat.mask(Stat.HP_PCT, Stat.HP_FLAT, Stat.COST, Stat.COOLDOWN, Stat.AGILITY);
    private static final int SUPPORT = Stat.mask(Stat.COST, Stat.COOLDOWN, Stat.HP_PCT, Stat.HP_FLAT);
    private static final int GENERIC = Stat.mask(Stat.MELEE_FLAT, Stat.RANGED_FLAT, Stat.MELEE_PCT, Stat.RANGED_PCT, Stat.CRIT_DMG, Stat.COST);

    private static final String REF = "参考攻略的通用推荐，可自行勾选";
    private static final String MANUAL = "按你的《装备刷取手册》";

    public static final SetDef[] SETS = build();

    private static SetDef[] build() {
        List<SetDef> l = new ArrayList<>();

        // ---- 手册里明确规定的5个套装 ----
        SetDef lucky = new SetDef("幸运儿", "Lucky Guy", true, "传奇", "首次受到致命伤害时保留1点生命",
            Stat.mask(Stat.HP_PCT, Stat.HP_FLAT, Stat.AGILITY, Stat.COST, Stat.COOLDOWN), MANUAL);
        lucky.must = Stat.COST.bit();
        lucky.book = Stat.HP_PCT.bit();

        SetDef gent = new SetDef("绅士", "Gentleman", true, "传奇", "暴击后2秒内主要伤害+50%",
            Stat.mask(Stat.COST, Stat.CRIT_DMG, Stat.MELEE_FLAT, Stat.MELEE_PCT, Stat.RANGED_FLAT, Stat.RANGED_PCT, Stat.COOLDOWN), MANUAL);
        gent.must = Stat.COST.bit();
        gent.exclusive = true;
        gent.book = Stat.mask(Stat.CRIT_CHANCE, Stat.MELEE_PCT);

        SetDef patriot = new SetDef("爱国者", "Patriot", true, "传奇", "每有一名友军死亡，主要伤害+7%",
            Stat.mask(Stat.RANGED_FLAT, Stat.RANGED_PCT, Stat.CRIT_DMG, Stat.CRIT_CHANCE, Stat.RANGE), MANUAL);
        patriot.watch = Stat.AGILITY.bit();
        patriot.book = Stat.mask(Stat.RANGED_PCT, Stat.CRIT_CHANCE, Stat.CRIT_DMG);

        SetDef scout = new SetDef("童子军", "Scout", true, "传奇", "击杀敌人时获得相当于20%最大生命的护盾，持续3秒",
            Stat.mask(Stat.HP_PCT, Stat.HP_FLAT, Stat.MELEE_FLAT, Stat.MELEE_PCT, Stat.COOLDOWN, Stat.COST), MANUAL);
        scout.must = Stat.COST.bit();
        scout.book = Stat.MELEE_PCT.bit();

        SetDef tactical = new SetDef("战术", "Tactical", true, "史诗", "无视敌人50%防弹抗性",
            Stat.mask(Stat.RANGE, Stat.RANGED_FLAT, Stat.RANGED_PCT, Stat.COST, Stat.CRIT_DMG), MANUAL);
        tactical.must = Stat.COST.bit();
        tactical.epic = true;

        // ---- 其余套装：按参考攻略给通用推荐 ----
        SetDef builder = new SetDef("建筑工", "Builder", true, "史诗", "25%几率免疫伤害", TANK, REF);
        builder.epic = true;
        l.add(builder);
        l.add(tactical);
        l.add(new SetDef("军人", "Military", true, "传奇", "30%几率每次射击多发射2倍子弹", RANGED, REF));
        l.add(new SetDef("猎人", "Hunter", true, "传奇", "目标每远15距离，主要伤害+5%", RANGED, REF));
        l.add(gent);
        l.add(new SetDef("外科医生", "Surgery", false, "传奇", "生命值低于50%时主要伤害翻倍", GENERIC, REF));
        l.add(new SetDef("健身", "Fitness", true, "传奇", "进攻性提升到100", GENERIC, REF));
        l.add(new SetDef("瑞士", "SwissMade", true, "传奇", "主要伤害+17%", GENERIC, REF));
        l.add(new SetDef("老大", "Boss", true, "传奇", "该单位登场时，全体单位主要伤害+25%，持续3秒", SUPPORT, REF));
        l.add(new SetDef("职业杀手", "Hitman", true, "传奇", "生命值未满时暴击伤害+30%", GENERIC | Stat.CRIT_CHANCE.bit(), REF));
        l.add(new SetDef("赌博", "Gambling", false, "传奇", "生命值未满时暴击几率+25%", GENERIC | Stat.CRIT_CHANCE.bit(), REF));
        l.add(new SetDef("消防员", "Firefighter", false, "传奇", "对燃烧单位伤害+30%", GENERIC, REF));
        l.add(lucky);
        l.add(scout);
        l.add(new SetDef("大男孩", "Big Boy", true, "传奇", "每1000点生命值，伤害+5%",
            Stat.mask(Stat.HP_PCT, Stat.HP_FLAT, Stat.MELEE_FLAT, Stat.MELEE_PCT, Stat.COST), REF));
        l.add(patriot);
        l.add(new SetDef("破冰者", "Ice Breaker", false, "传奇", "对眩晕或冰冻敌人主要伤害+30%", GENERIC, REF));
        l.add(new SetDef("孤狼", "Lone Wolf", false, "传奇", "主要伤害+55%，战场上每多一名其他单位减少20%", GENERIC, REF));
        l.add(new SetDef("齿轮传动", "Gear Train", false, "传奇", "远程伤害每次射击+2%直到换弹，最高+100%", RANGED, REF));
        l.add(new SetDef("针垫", "Pincushion", false, "传奇", "每受到一次远程或近战攻击，伤害+5%",
            Stat.mask(Stat.HP_PCT, Stat.HP_FLAT, Stat.MELEE_PCT, Stat.RANGED_PCT, Stat.COST), REF));
        l.add(new SetDef("碳纤维", "Carbon", false, "传奇", "无视首次受到伤害的60%和第二次的40%", TANK, REF));
        l.add(new SetDef("穿刺", "Piercing", false, "传奇", "子弹穿透首个目标，对下一个目标造成30%伤害", RANGED, REF));
        l.add(new SetDef("创伤包", "Trauma Kit", false, "传奇", "对流血敌人主要伤害+35%", MELEE, REF));
        l.add(new SetDef("遗物", "Relics", false, "传奇", "该单位每有350魅力，位置最靠前的友军伤害+5%",
            Stat.mask(Stat.CHARISMA, Stat.COST, Stat.COOLDOWN, Stat.HP_PCT, Stat.HP_FLAT), REF));
        return l.toArray(new SetDef[0]);
    }

    /** 把某个套装的默认推荐套进规则。 */
    public static RuleConfig defaultRule(SetDef d) {
        RuleConfig c = new RuleConfig();
        c.wanted = d.wanted;
        c.must = d.must;
        c.exclusiveMeleeRanged = d.exclusive;
        c.watchMain = d.watch;
        c.bookMain = d.book;
        c.knifeMain = d.knife;
        c.cupMain = d.cup;
        c.qualityMode = d.epic ? 1 : 0;
        return c;
    }

    public static String[] displayNames() {
        String[] a = new String[SETS.length];
        for (int i = 0; i < SETS.length; i++) a[i] = SETS[i].displayName();
        return a;
    }
}
