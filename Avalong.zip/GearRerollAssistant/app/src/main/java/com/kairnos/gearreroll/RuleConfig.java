package com.kairnos.gearreroll;

/** 一次刷装备任务的筛选规则（纯数据，不依赖安卓）。 */
public final class RuleConfig {
    /** 想要的副词条（命中计数）。 */
    public int wanted;
    /** 必带副词条：缺任何一个都算垃圾。 */
    public int must;
    /** 至少命中几条才保留。 */
    public int minHits = 3;
    /** 主副词条或副词条之间重复 → 淘汰。 */
    public boolean rejectDuplicate = true;
    /** 近战系与远程系同时出现 → 淘汰（绅士）。 */
    public boolean exclusiveMeleeRanged = false;
    /** 各部位允许的主词条；全选 = 不限制。 */
    public int watchMain = Stat.mask(Stat.COOLDOWN, Stat.AGILITY);
    public int bookMain = Stat.mask(Stat.CRIT_CHANCE, Stat.CRIT_DMG, Stat.HP_PCT, Stat.MELEE_PCT, Stat.RANGED_PCT);
    public int knifeMain = Stat.mask(Stat.MELEE_FLAT, Stat.RANGED_FLAT);
    public int cupMain = Stat.mask(Stat.HP_FLAT);
    /** 0=传奇(金,4条副词条) 1=史诗(紫,3条) 2=自动按识别结果。 */
    public int qualityMode = 0;

    public int mainMaskFor(Stat.Slot slot) {
        switch (slot) {
            case WATCH: return watchMain;
            case BOOK: return bookMain;
            case KNIFE: return knifeMain;
            default: return cupMain;
        }
    }
}
