package com.kairnos.gearreroll;

import java.util.ArrayList;
import java.util.List;

/** 一次截屏识别后得到的结构化信息。 */
public final class ScreenRead {
    public enum Quality { UNKNOWN, COMMON, RARE, EPIC, LEGENDARY }

    public int level = -1;
    public boolean maxLevel;
    public Quality quality = Quality.UNKNOWN;
    public boolean qualityConflict;

    public Stat main;
    public boolean mainUnknown;
    public final List<Stat> subs = new ArrayList<>();
    public int unknownSubs;
    public final List<String> unknownTexts = new ArrayList<>();

    public OcrLine btnContinue, btnBack, btnReroll;
    public boolean lockedWord;
    public String warnWord = "";
    public final List<String> setNamesFound = new ArrayList<>();

    public String text = "";
    public int lineCount;

    public boolean isResult() { return btnContinue != null && btnBack != null; }
    public boolean isConfirm() { return btnReroll != null && btnContinue == null; }

    /** 词条签名，用来判断重掷动画是否已结束、结果是否变化。 */
    public String statSignature() {
        StringBuilder sb = new StringBuilder();
        sb.append(main == null ? "?" : main.name()).append('|');
        for (Stat s : subs) sb.append(s.name()).append(',');
        sb.append('|').append(unknownSubs);
        return sb.toString();
    }

    public String statSummary() {
        StringBuilder sb = new StringBuilder();
        sb.append("主:").append(main == null ? "未识别" : main.label);
        sb.append(" 副:");
        if (subs.isEmpty() && unknownSubs == 0) sb.append("无");
        for (int i = 0; i < subs.size(); i++) {
            if (i > 0) sb.append("，");
            sb.append(subs.get(i).label);
        }
        if (unknownSubs > 0) sb.append("（另有").append(unknownSubs).append("条未识别）");
        return sb.toString();
    }
}
