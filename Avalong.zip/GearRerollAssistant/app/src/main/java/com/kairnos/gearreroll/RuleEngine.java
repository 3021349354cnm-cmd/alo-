package com.kairnos.gearreroll;

import java.util.HashSet;
import java.util.Set;

/** 按用户规则判定一件装备要不要保留。无法确定时返回 UNKNOWN，绝不猜。 */
public final class RuleEngine {
    private RuleEngine() {}

    public static Verdict evaluate(ScreenRead r, RuleConfig c) {
        if (r.mainUnknown || r.main == null) {
            return new Verdict(Verdict.Kind.UNKNOWN, "没有读到主词条", 0);
        }
        int minSubs, maxSubs;
        boolean epic;
        if (c.qualityMode == 1) epic = true;
        else if (c.qualityMode == 2) epic = r.quality == ScreenRead.Quality.EPIC;
        else epic = false;
        if (c.qualityMode == 2 && r.quality == ScreenRead.Quality.UNKNOWN) { minSubs = 2; maxSubs = 4; }
        else if (epic) { minSubs = 2; maxSubs = 3; }
        else { minSubs = 3; maxSubs = 4; }

        int total = r.subs.size() + r.unknownSubs;
        if (total > maxSubs) {
            return new Verdict(Verdict.Kind.UNKNOWN, "副词条行数异常（读到" + total + "条）", 0);
        }
        if (total < minSubs) {
            return new Verdict(Verdict.Kind.UNKNOWN, "副词条只读到" + total + "条，可能漏识别", 0);
        }

        int allowed = c.mainMaskFor(r.main.slotAsMain());
        if ((allowed & r.main.bit()) == 0) {
            return new Verdict(Verdict.Kind.REJECT, "主词条不符：" + r.main.label, 0);
        }

        if (c.rejectDuplicate) {
            Set<Stat> seen = new HashSet<>();
            for (Stat s : r.subs) {
                if (s == r.main) return new Verdict(Verdict.Kind.REJECT, "主副词条重复：" + s.label, 0);
                if (!seen.add(s)) return new Verdict(Verdict.Kind.REJECT, "副词条重复：" + s.label, 0);
            }
        }

        if (c.exclusiveMeleeRanged) {
            boolean melee = r.main.isMelee(), ranged = r.main.isRanged();
            for (Stat s : r.subs) { if (s.isMelee()) melee = true; if (s.isRanged()) ranged = true; }
            if (melee && ranged) return new Verdict(Verdict.Kind.REJECT, "近战与远程混搭", 0);
        }

        int have = 0;
        for (Stat s : r.subs) have |= s.bit();
        int missing = c.must & ~have;
        int missingCount = Integer.bitCount(missing);
        if (missingCount > r.unknownSubs) {
            return new Verdict(Verdict.Kind.REJECT, "缺少必带词条：" + Stat.names(missing), 0);
        }

        int hits = 0;
        for (Stat s : r.subs) if ((c.wanted & s.bit()) != 0) hits++;

        if (missingCount == 0 && hits >= c.minHits) {
            return new Verdict(Verdict.Kind.KEEP, "命中" + hits + "条", hits);
        }
        if (hits + r.unknownSubs >= c.minHits) {
            return new Verdict(Verdict.Kind.UNKNOWN, "有" + r.unknownSubs + "条词条没识别出来，无法确定", hits);
        }
        return new Verdict(Verdict.Kind.REJECT, "只命中" + hits + "条（需要" + c.minHits + "条）", hits);
    }
}
