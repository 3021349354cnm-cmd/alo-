package com.kairnos.gearreroll;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Avalon 自动化服务：截屏 → 离线中文文字识别 → 按规则判断 → 手势点击。
 * 全程不依赖游戏控件是否暴露文字。
 */
public class GearAutomationService extends AccessibilityService {

    // ---------- 给界面读取的运行信息 ----------
    public static volatile GearAutomationService instance;
    public static volatile String stateText = "未启动";
    public static volatile int rolls, kept, skipped, pages;
    public static final ArrayList<String> LOG = new ArrayList<>();

    public static void log(String msg) {
        String t = new SimpleDateFormat("HH:mm:ss", Locale.CHINA).format(new Date());
        synchronized (LOG) {
            LOG.add(t + "  " + msg);
            while (LOG.size() > 80) LOG.remove(0);
        }
    }

    public static String recentLog(int n) {
        StringBuilder sb = new StringBuilder();
        synchronized (LOG) {
            int from = Math.max(0, LOG.size() - n);
            for (int i = from; i < LOG.size(); i++) sb.append(LOG.get(i)).append('\n');
        }
        return sb.toString().trim();
    }

    private static final class StopEx extends RuntimeException {
        StopEx(String m) { super(m); }
    }

    private static final class Snap {
        ScreenRead read;
        List<OcrLine> lines;
        int w, h;
        int[] sig;
    }

    // ---------- 状态 ----------
    private final Handler main = new Handler(Looper.getMainLooper());
    private TextRecognizer recognizer;
    private WindowManager wm;
    private volatile boolean running, paused, stopReq;
    private Thread worker;
    private long lastShotAt;
    private volatile int lastShotErr;

    // 悬浮控制条
    private LinearLayout panel;
    private WindowManager.LayoutParams panelLp;
    private TextView panelStatus;
    private Button btnStart;
    private volatile Rect panelRect = new Rect();
    private View calibView;
    private View diagView;

    // 本次任务参数
    private RuleConfig rule;
    private GearData.SetDef curSet;
    private boolean verifySet;
    private int cols, rows, maxRolls, scrollPct;
    private boolean autoScroll;
    private float rollFx, rollFy, gridFx, gridFy, gridDx, gridDy;
    private int openFails;

    // ================= 生命周期 =================

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        recognizer = TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());
        setState("无障碍已连接");
        log("无障碍服务已连接");
        main.post(new Runnable() { @Override public void run() { showPanel(); } });
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override public void onInterrupt() {
        if (running) { paused = true; setState("已暂停：系统中断了无障碍服务"); }
    }

    @Override public boolean onUnbind(android.content.Intent intent) {
        shutdown();
        return super.onUnbind(intent);
    }

    @Override public void onDestroy() {
        shutdown();
        super.onDestroy();
    }

    private void shutdown() {
        stopReq = true;
        paused = false;
        instance = null;
        main.removeCallbacksAndMessages(null);
        try { hidePanel(); } catch (Throwable t) { }
        try { closeCalibration(); } catch (Throwable t) { }
        try { closeDiag(); } catch (Throwable t) { }
        if (recognizer != null) { try { recognizer.close(); } catch (Throwable t) { } recognizer = null; }
    }

    private static void setState(String s) { stateText = s; }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private void toast(final String msg) {
        main.post(new Runnable() { @Override public void run() { Toast.makeText(GearAutomationService.this, msg, Toast.LENGTH_LONG).show(); } });
    }

    private int[] realSize() {
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        return new int[]{dm.widthPixels, dm.heightPixels};
    }

    // ================= 悬浮控制条 =================

    public void showPanel() {
        if (panel != null || wm == null) return;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(8), dp(6), dp(8), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xD91C1C1E);
        bg.setCornerRadius(dp(22));
        bg.setStroke(dp(1), 0x40FFFFFF);
        box.setBackground(bg);

        panelStatus = new TextView(this);
        panelStatus.setTextColor(0xFFF2EBDD);
        panelStatus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        panelStatus.setMaxWidth(dp(330));
        panelStatus.setText("Avalon · 按住这里可拖动");
        box.addView(panelStatus, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rlp.topMargin = dp(5);
        box.addView(row, rlp);

        btnStart = mkBtn("开始", new View.OnClickListener() { @Override public void onClick(View v) { onStartClicked(); } });
        addBtn(row, btnStart);
        addBtn(row, mkBtn("暂停", new View.OnClickListener() { @Override public void onClick(View v) { onPauseClicked(); } }));
        addBtn(row, mkBtn("停止", new View.OnClickListener() { @Override public void onClick(View v) { onStopClicked(); } }));
        addBtn(row, mkBtn("校准", new View.OnClickListener() { @Override public void onClick(View v) { startCalibration(); } }));
        addBtn(row, mkBtn("测试", new View.OnClickListener() { @Override public void onClick(View v) { runDiagnostic(); } }));
        addBtn(row, mkBtn("×", new View.OnClickListener() { @Override public void onClick(View v) { hidePanel(); } }));

        panelLp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);
        panelLp.gravity = Gravity.TOP | Gravity.START;
        panelLp.x = dp(12);
        panelLp.y = dp(8);

        panelStatus.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy; int ox, oy;
            @Override public boolean onTouch(View v, MotionEvent e) {
                int a = e.getAction();
                if (a == MotionEvent.ACTION_DOWN) { sx = e.getRawX(); sy = e.getRawY(); ox = panelLp.x; oy = panelLp.y; }
                else if (a == MotionEvent.ACTION_MOVE) {
                    panelLp.x = ox + Math.round(e.getRawX() - sx);
                    panelLp.y = oy + Math.round(e.getRawY() - sy);
                    try { wm.updateViewLayout(panel, panelLp); } catch (Throwable t) { }
                    updatePanelRect();
                }
                return true;
            }
        });
        box.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override public void onLayoutChange(View v, int l, int t, int r, int b, int ol, int ot, int orr, int ob) { updatePanelRect(); }
        });

        panel = box;
        try {
            wm.addView(panel, panelLp);
        } catch (Throwable t) {
            panel = null;
            log("悬浮条显示失败：" + t.getClass().getSimpleName());
            return;
        }
        updatePanelRect();
        panel.setAlpha(0f);
        panel.animate().alpha(1f).setDuration(300).start();
        main.removeCallbacks(ticker);
        main.post(ticker);
    }

    public void hidePanel() {
        main.removeCallbacks(ticker);
        if (panel != null && wm != null) {
            try { wm.removeView(panel); } catch (Throwable t) { }
        }
        panel = null;
        panelRect = new Rect();
    }

    public boolean isPanelShown() { return panel != null; }

    private void updatePanelRect() {
        if (panel == null || panelLp == null) return;
        int m = dp(6);
        panelRect = new Rect(panelLp.x - m, panelLp.y - m, panelLp.x + panel.getWidth() + m, panelLp.y + panel.getHeight() + m);
    }

    private Button mkBtn(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        b.setAllCaps(false);
        b.setTextColor(0xFFFFFFFF);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(10), dp(6), dp(10), dp(6));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0x40FFFFFF);
        g.setCornerRadius(dp(14));
        b.setBackground(g);
        b.setOnClickListener(l);
        return b;
    }

    private void addBtn(LinearLayout row, Button b) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = dp(4);
        row.addView(b, lp);
    }

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (panel == null) return;
            StringBuilder sb = new StringBuilder(stateText);
            if (running) sb.append("\n重掷 ").append(rolls).append(" · 保留 ").append(kept).append(" · 跳过 ").append(skipped);
            panelStatus.setText(sb.toString());
            if (btnStart != null) btnStart.setText(running ? (paused ? "继续" : "运行中") : "开始");
            main.postDelayed(this, 500);
        }
    };

    private void onStartClicked() {
        if (!running) startWorker();
        else if (paused) { paused = false; setState("运行中"); log("已继续"); }
    }

    private void onPauseClicked() {
        if (running && !paused) { paused = true; setState("已暂停（手动）"); log("手动暂停"); }
    }

    private void onStopClicked() {
        if (running) { stopReq = true; paused = false; }
        else setState("未启动");
    }

    // ================= 校准 =================

    private void startCalibration() {
        if (running) { toast("请先点“停止”再校准"); return; }
        if (calibView != null || wm == null) return;
        final String[] prompts = {
            "① 点【重掷图标】的中心（绿色循环箭头）",
            "② 点装备列表【第1行第1个】格子的中心",
            "③ 点【第1行第2个】格子的中心（右边相邻）",
            "④ 点【第2行第1个】格子的中心（正下方）"
        };
        final float[][] pts = new float[4][2];
        final int[] step = {0};
        final int[] sz = realSize();
        final FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0x55000000);

        final TextView hint = new TextView(this);
        hint.setTextColor(0xFFFFFFFF);
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        hint.setPadding(dp(14), dp(10), dp(14), dp(10));
        GradientDrawable hb = new GradientDrawable();
        hb.setColor(0xE615171A);
        hb.setCornerRadius(dp(10));
        hint.setBackground(hb);
        hint.setText("先在游戏里点开一件1级装备，让重掷图标显示出来。\n" + prompts[0]);
        FrameLayout.LayoutParams hlp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        hlp.topMargin = dp(24);
        root.addView(hint, hlp);

        Button cancel = mkBtn("取消校准", new View.OnClickListener() { @Override public void onClick(View v) { closeCalibration(); } });
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        clp.bottomMargin = dp(40);
        root.addView(cancel, clp);

        root.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() != MotionEvent.ACTION_UP) return true;
                int s = step[0];
                if (s >= 4) return true;
                pts[s][0] = e.getRawX() / sz[0];
                pts[s][1] = e.getRawY() / sz[1];
                View dot = new View(GearAutomationService.this);
                GradientDrawable dg = new GradientDrawable();
                dg.setShape(GradientDrawable.OVAL);
                dg.setColor(0xFFE5484D);
                dot.setBackground(dg);
                FrameLayout.LayoutParams dl = new FrameLayout.LayoutParams(dp(18), dp(18));
                dl.leftMargin = Math.round(e.getRawX()) - dp(9);
                dl.topMargin = Math.round(e.getRawY()) - dp(9);
                root.addView(dot, dl);
                step[0]++;
                if (step[0] < 4) {
                    hint.setText("已记录 " + step[0] + "/4\n" + prompts[step[0]]);
                } else {
                    float dx = pts[2][0] - pts[1][0];
                    float dy = pts[3][1] - pts[1][1];
                    if (dx < 0.01f || dy < 0.01f) {
                        toast("格子间距不合理（第3点要在第2点右边，第4点要在其下方），请重新校准");
                    } else {
                        Cfg.saveCalibration(GearAutomationService.this, pts[0][0], pts[0][1], pts[1][0], pts[1][1], dx, dy);
                        log("校准完成");
                        toast("校准完成");
                    }
                    closeCalibration();
                }
                return true;
            }
        });

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);
        try {
            wm.addView(root, lp);
            calibView = root;
        } catch (Throwable t) {
            toast("校准层显示失败：" + t.getClass().getSimpleName());
        }
    }

    private void closeCalibration() {
        if (calibView != null && wm != null) {
            try { wm.removeView(calibView); } catch (Throwable t) { }
        }
        calibView = null;
    }

    // ================= 识别测试 =================

    private void runDiagnostic() {
        if (running && !paused) { toast("运行中不能测试，请先暂停"); return; }
        setState("正在截屏识别…");
        new Thread(new Runnable() {
            @Override public void run() {
                String text;
                try {
                    Snap s = snapCore(false);
                    text = (s == null) ? "截屏或识别失败，错误代码 " + lastShotErr : describe(s);
                } catch (Throwable t) {
                    text = "测试出错：" + t.getClass().getSimpleName() + " " + t.getMessage();
                }
                final String shown = text;
                log("识别测试完成");
                main.post(new Runnable() { @Override public void run() {
                    if (!running) setState("未启动");
                    showDiag(shown);
                } });
            }
        }, "avalon-diag").start();
    }

    private String describe(Snap s) {
        ScreenRead r = s.read;
        StringBuilder sb = new StringBuilder();
        sb.append("屏幕 ").append(s.w).append("×").append(s.h).append("，识别 ").append(s.lines.size()).append(" 行\n");
        sb.append("界面：").append(r.isResult() ? "重掷结果框" : r.isConfirm() ? "重掷确认框" : "其他（详情页/列表）").append('\n');
        sb.append("等级：").append(r.level < 0 ? "没读到" : (r.level + (r.maxLevel ? "(Max)" : "")));
        sb.append("　品质：").append(qName(r.quality)).append(r.qualityConflict ? "(冲突)" : "");
        sb.append("　已装备字样：").append(r.lockedWord ? "有" : "无").append('\n');
        sb.append(r.statSummary()).append('\n');
        if (!r.unknownTexts.isEmpty()) sb.append("未识别词条行：").append(r.unknownTexts).append('\n');
        sb.append("按钮：继续").append(pos(r.btnContinue)).append(" 返回").append(pos(r.btnBack)).append(" 重掷").append(pos(r.btnReroll)).append('\n');
        if (!r.warnWord.isEmpty()) sb.append("提示词：").append(r.warnWord).append('\n');
        if (!r.setNamesFound.isEmpty()) sb.append("看到的套装名：").append(r.setNamesFound).append('\n');
        sb.append("─── 识别到的文字（从上到下）───\n");
        List<OcrLine> sorted = new ArrayList<>(s.lines);
        java.util.Collections.sort(sorted, new java.util.Comparator<OcrLine>() {
            @Override public int compare(OcrLine a, OcrLine b) { return a.cy() != b.cy() ? Integer.compare(a.cy(), b.cy()) : Integer.compare(a.l, b.l); }
        });
        int n = 0;
        for (OcrLine l : sorted) {
            sb.append('(').append(l.cx()).append(',').append(l.cy()).append(") ").append(l.text).append('\n');
            if (++n >= 120) { sb.append("…\n"); break; }
        }
        return sb.toString();
    }

    private static String pos(OcrLine l) { return l == null ? "[无]" : "[" + l.cx() + "," + l.cy() + "]"; }

    private static String qName(ScreenRead.Quality q) {
        switch (q) {
            case LEGENDARY: return "传奇";
            case EPIC: return "史诗";
            case RARE: return "稀有";
            case COMMON: return "普通";
            default: return "没读到";
        }
    }

    private void showDiag(String text) {
        closeDiag();
        if (wm == null) return;
        int[] sz = realSize();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(0xF2101214);
        box.setPadding(dp(12), dp(8), dp(12), dp(8));
        Button close = mkBtn("关闭", new View.OnClickListener() { @Override public void onClick(View v) { closeDiag(); } });
        box.addView(close, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        ScrollView sv = new ScrollView(this);
        TextView tv = new TextView(this);
        tv.setTextColor(0xFFE8E4DA);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        tv.setText(text);
        sv.addView(tv);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        slp.topMargin = dp(6);
        box.addView(sv, slp);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, Math.round(sz[1] * 0.72f),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.BOTTOM;
        try { wm.addView(box, lp); diagView = box; } catch (Throwable t) { toast("结果窗口显示失败"); }
    }

    private void closeDiag() {
        if (diagView != null && wm != null) {
            try { wm.removeView(diagView); } catch (Throwable t) { }
        }
        diagView = null;
    }

    // ================= 截屏 / 识别 / 手势 =================

    private void sleepRaw(long ms) {
        if (ms <= 0) return;
        try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    private void sleepMs(long ms) {
        long end = System.currentTimeMillis() + ms;
        while (true) {
            if (stopReq) throw new StopEx("已停止");
            long left = end - System.currentTimeMillis();
            if (left <= 0) return;
            sleepRaw(Math.min(left, 100));
        }
    }

    private void checkStop() {
        while (paused && !stopReq) sleepRaw(200);
        if (stopReq) throw new StopEx("已停止");
    }

    private void pauseFor(String msg) {
        paused = true;
        setState("已暂停：" + msg);
        log("暂停：" + msg);
        checkStop();
        setState("运行中");
    }

    private Bitmap takeShot() {
        final CountDownLatch latch = new CountDownLatch(1);
        final Bitmap[] out = new Bitmap[1];
        final int[] err = new int[]{0};
        try {
            takeScreenshot(android.view.Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
                @Override public void onSuccess(ScreenshotResult result) {
                    HardwareBuffer buf = result.getHardwareBuffer();
                    try {
                        Bitmap hw = Bitmap.wrapHardwareBuffer(buf, result.getColorSpace());
                        if (hw != null) out[0] = hw.copy(Bitmap.Config.ARGB_8888, false);
                        else err[0] = -2;
                    } catch (Throwable t) {
                        err[0] = -2;
                    } finally {
                        if (buf != null) buf.close();
                        latch.countDown();
                    }
                }
                @Override public void onFailure(int errorCode) {
                    err[0] = errorCode;
                    latch.countDown();
                }
            });
        } catch (Throwable t) {
            lastShotErr = -3;
            return null;
        }
        try { latch.await(8, TimeUnit.SECONDS); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        lastShotErr = err[0];
        return out[0];
    }

    private List<OcrLine> ocr(Bitmap bmp) {
        TextRecognizer rec = recognizer;
        if (rec == null) return null;
        final CountDownLatch latch = new CountDownLatch(1);
        final Text[] res = new Text[1];
        rec.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener(t -> res[0] = t)
            .addOnCompleteListener(t -> latch.countDown());
        try { latch.await(25, TimeUnit.SECONDS); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        if (res[0] == null) return null;
        List<OcrLine> out = new ArrayList<>();
        for (Text.TextBlock b : res[0].getTextBlocks()) {
            for (Text.Line line : b.getLines()) {
                Rect bb = line.getBoundingBox();
                String tx = line.getText();
                if (bb == null || tx == null || tx.trim().isEmpty()) continue;
                out.add(new OcrLine(tx, bb.left, bb.top, bb.right, bb.bottom));
            }
        }
        return out;
    }

    private int[] gridSig(Bitmap b) {
        if (gridDx <= 0f) return null;
        int W = b.getWidth(), H = b.getHeight();
        int x0 = Math.max(0, Math.round((gridFx - gridDx / 2f) * W));
        int x1 = Math.min(W - 1, Math.round((gridFx + (cols - 1) * gridDx + gridDx / 2f) * W));
        int y0 = Math.max(0, Math.round((gridFy - gridDy / 2f) * H));
        int y1 = Math.min(H - 1, Math.round((gridFy + (rows - 1) * gridDy + gridDy / 2f) * H));
        if (x1 <= x0 || y1 <= y0) return null;
        int[] sig = new int[24 * 16];
        for (int gy = 0; gy < 16; gy++) {
            for (int gx = 0; gx < 24; gx++) {
                int px = x0 + (x1 - x0) * (2 * gx + 1) / 48;
                int py = y0 + (y1 - y0) * (2 * gy + 1) / 32;
                int c = b.getPixel(px, py);
                int r = (c >> 16) & 0xFF, g = (c >> 8) & 0xFF, bl = c & 0xFF;
                sig[gy * 24 + gx] = (r * 30 + g * 59 + bl * 11) / 100;
            }
        }
        return sig;
    }

    private static boolean sigSame(int[] a, int[] b) {
        if (a == null || b == null || a.length != b.length) return false;
        long sum = 0;
        for (int i = 0; i < a.length; i++) sum += Math.abs(a[i] - b[i]);
        return sum / (double) a.length < 8.0;
    }

    /** 截屏并识别一次；失败返回null。不检查暂停/停止，测试按钮也用它。 */
    private Snap snapCore(boolean withSig) {
        for (int attempt = 0; attempt < 4; attempt++) {
            long wait = 450 - (System.currentTimeMillis() - lastShotAt);
            if (wait > 0) sleepRaw(wait);
            Bitmap bmp = takeShot();
            lastShotAt = System.currentTimeMillis();
            if (bmp == null) { sleepRaw(lastShotErr == 3 ? 700 : 400); continue; }
            Snap s = new Snap();
            s.w = bmp.getWidth();
            s.h = bmp.getHeight();
            if (withSig) { try { s.sig = gridSig(bmp); } catch (Throwable t) { s.sig = null; } }
            List<OcrLine> all = ocr(bmp);
            bmp.recycle();
            if (all == null) { lastShotErr = -1; sleepRaw(400); continue; }
            Rect pr = panelRect;
            List<OcrLine> kept2 = new ArrayList<>();
            for (OcrLine l : all) if (!pr.contains(l.cx(), l.cy())) kept2.add(l);
            s.lines = kept2;
            s.read = ItemParser.parse(kept2, s.w, s.h);
            return s;
        }
        return null;
    }

    private Snap snap(boolean withSig) {
        while (true) {
            checkStop();
            Snap s = snapCore(withSig);
            if (s != null) return s;
            pauseFor("截屏或识别失败（代码 " + lastShotErr + "），请确认无障碍权限正常、游戏没有禁止截屏");
        }
    }

    private boolean gesture(Path p, long dur) {
        final CountDownLatch latch = new CountDownLatch(1);
        GestureDescription g = new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(p, 0, dur)).build();
        boolean sent;
        try {
            sent = dispatchGesture(g, new GestureResultCallback() {
                @Override public void onCompleted(GestureDescription gd) { latch.countDown(); }
                @Override public void onCancelled(GestureDescription gd) { latch.countDown(); }
            }, null);
        } catch (Throwable t) {
            return false;
        }
        if (!sent) return false;
        try { latch.await(dur + 2500, TimeUnit.MILLISECONDS); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        return true;
    }

    private void tapPx(int x, int y) {
        checkStop();
        Path p = new Path();
        p.moveTo(x, y);
        if (!gesture(p, 70)) pauseFor("点击手势发送失败，请检查无障碍服务是否仍开启");
        sleepRaw(60);
    }

    private void tapFrac(float fx, float fy) {
        int[] sz = realSize();
        tapPx(Math.round(fx * sz[0]), Math.round(fy * sz[1]));
    }

    private void tapLine(OcrLine l) { tapPx(l.cx(), l.cy()); }

    private void scrollPage() {
        int[] sz = realSize();
        float x = (gridFx + (cols - 1) * gridDx / 2f) * sz[0];
        float dist = rows * gridDy * sz[1] * scrollPct / 100f;
        float startY = (gridFy + (rows - 1) * gridDy + gridDy * 0.4f) * sz[1];
        startY = Math.min(startY, sz[1] * 0.96f);
        float endY = startY - dist;
        if (endY < sz[1] * 0.03f) { endY = sz[1] * 0.03f; }
        Path p = new Path();
        p.moveTo(x, startY);
        p.lineTo(x, endY);
        if (!gesture(p, 900)) pauseFor("翻页手势发送失败");
        sleepMs(900);
    }

    private void checkForeground() {
        String target = Cfg.targetPackage(this);
        if (target.isEmpty()) return;
        for (int i = 0; i < 3; i++) {
            String pkg = null;
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null) {
                CharSequence cs = root.getPackageName();
                if (cs != null) pkg = cs.toString();
                root.recycle();
            }
            if (pkg == null || pkg.equals(target) || pkg.equals(getPackageName())) return;
            sleepMs(1200);
        }
        pauseFor("游戏不在前台，请切回游戏后点“继续”");
    }

    // ================= 主流程 =================

    private void startWorker() {
        if (!Cfg.safeAck(this)) { toast("请先在 Avalon 里勾选“已人工确认…”"); return; }
        if (!Cfg.calibrated(this)) { toast("请先点“校准”"); return; }
        closeDiag();
        stopReq = false;
        paused = false;
        running = true;
        rolls = 0; kept = 0; skipped = 0; pages = 0; openFails = 0;
        setState("运行中");
        worker = new Thread(new Runnable() { @Override public void run() { runLoop(); } }, "avalon-worker");
        worker.start();
    }

    private void runLoop() {
        String end;
        try {
            runMain();
            end = "已完成";
        } catch (StopEx e) {
            end = (e.getMessage() == null || e.getMessage().isEmpty()) ? "已停止" : e.getMessage();
        } catch (Throwable t) {
            end = "出错停止：" + t.getClass().getSimpleName() + " " + t.getMessage();
        }
        running = false;
        paused = false;
        stopReq = false;
        setState(end);
        log(end + "（重掷" + rolls + "次，保留" + kept + "件，跳过" + skipped + "格）");
    }

    private void runMain() {
        int setIdx = Cfg.setIndex(this);
        curSet = GearData.SETS[setIdx];
        rule = Cfg.loadRule(this, setIdx);
        verifySet = Cfg.verifySet(this);
        cols = Cfg.columns(this);
        rows = Cfg.rows(this);
        autoScroll = Cfg.autoScroll(this);
        maxRolls = Cfg.maxRolls(this);
        scrollPct = Cfg.scrollPct(this);
        rollFx = Cfg.f(this, "roll_fx"); rollFy = Cfg.f(this, "roll_fy");
        gridFx = Cfg.f(this, "grid_fx"); gridFy = Cfg.f(this, "grid_fy");
        gridDx = Cfg.f(this, "grid_dx"); gridDy = Cfg.f(this, "grid_dy");

        log("开始：" + curSet.zh + " 想要[" + Stat.names(rule.wanted) + "] 必带[" + Stat.names(rule.must) + "] 至少命中" + rule.minHits);

        int idx = 0;
        int emptyPages = 0, sameCount = 0, levelOneThisPage = 0;
        int[] pageSig = null;
        boolean needPageSig = true;
        while (true) {
            checkStop();
            if (idx == 0 && needPageSig) {
                pageSig = snap(true).sig;
                needPageSig = false;
                levelOneThisPage = 0;
            }
            if (idx >= cols * rows) {
                if (levelOneThisPage == 0) emptyPages++; else emptyPages = 0;
                if (emptyPages >= 8) throw new StopEx("已完成：连续8页没有找到可刷的1级装备");
                if (!autoScroll) {
                    pauseFor("本页处理完，请手动翻到下一页后点“继续”");
                    idx = 0;
                    needPageSig = true;
                    continue;
                }
                scrollPage();
                pages++;
                Snap after = snap(true);
                if (sigSame(pageSig, after.sig)) {
                    sameCount++;
                    if (sameCount >= 2) throw new StopEx("已完成：已翻到列表末尾");
                } else {
                    sameCount = 0;
                }
                pageSig = after.sig;
                idx = 0;
                levelOneThisPage = 0;
                continue;
            }
            checkForeground();
            int col = idx % cols, row = idx / cols;
            int res = processCell(col, row);   // 0=处理完/跳过 1=需要重试本格 2=本格是可刷的1级装备
            if (res == 1) continue;
            if (res == 2) levelOneThisPage++;
            idx++;
            if (maxRolls > 0 && rolls >= maxRolls) throw new StopEx("已完成：达到最大重掷次数 " + maxRolls);
        }
    }

    private int processCell(int col, int row) {
        String where = "第" + (row + 1) + "行第" + (col + 1) + "格";
        tapFrac(gridFx + col * gridDx, gridFy + row * gridDy);
        sleepMs(900);
        Snap s = snap(false);
        ScreenRead r = s.read;

        if (!r.warnWord.isEmpty()) { pauseFor("画面出现提示“" + r.warnWord + "”"); return 1; }
        if (r.isResult()) { pauseFor("画面停在重掷结果框，不是装备列表。请手动回到列表后点“继续”"); return 1; }

        int lv = r.level;
        if (lv < 0) { sleepMs(500); s = snap(false); r = s.read; lv = r.level; }
        if (lv < 0 && r.isConfirm()) { pauseFor("画面停在重掷确认框，不是装备列表。请手动回到列表后点“继续”"); return 1; }
        if (lv < 0) { skipped++; log(where + "：没读到等级，跳过"); return 0; }
        if (lv != 1) { skipped++; log(where + "：" + lv + "级，跳过"); return 0; }
        if (r.lockedWord) { skipped++; log(where + "：带已装备/锁定字样，跳过"); return 0; }
        if (rule.qualityMode == 0 && r.quality == ScreenRead.Quality.EPIC) { skipped++; log(where + "：史诗品质，跳过（当前只刷传奇）"); return 0; }
        if (rule.qualityMode == 1 && r.quality == ScreenRead.Quality.LEGENDARY) { skipped++; log(where + "：传奇品质，跳过（当前只刷史诗）"); return 0; }
        if (r.quality == ScreenRead.Quality.COMMON || r.quality == ScreenRead.Quality.RARE) { skipped++; log(where + "：品质不够，跳过"); return 0; }
        if (verifySet && !r.setNamesFound.isEmpty() && !r.setNamesFound.contains(curSet.zh)) {
            pauseFor("看到的套装是 " + r.setNamesFound + "，和所选“" + curSet.zh + "”不符，请切换套装后点“继续”");
            return 1;
        }

        if (!openReroll()) {
            skipped++;
            openFails++;
            log(where + "：没弹出重掷界面，跳过");
            if (openFails >= 3) {
                pauseFor("连续3次没识别到重掷界面，请点“测试”查看识别结果");
                openFails = 0;
            }
            return 0;
        }
        openFails = 0;
        log(where + "：1级装备，开始重掷");
        rerollLoop();
        return 2;
    }

    private boolean openReroll() {
        for (int attempt = 0; attempt < 3; attempt++) {
            tapFrac(rollFx, rollFy);
            sleepMs(1000);
            Snap t = snap(false);
            if (t.read.isResult() || t.read.isConfirm()) return true;
        }
        return false;
    }

    private void rerollLoop() {
        String lastSig = "";
        String prevSig = "";
        int stable = 0, idle = 0, unknownRetry = 0;
        long actionAt = System.currentTimeMillis();
        while (true) {
            checkStop();
            Snap s = snap(false);
            ScreenRead r = s.read;
            if (!r.warnWord.isEmpty()) {
                pauseFor("画面出现提示“" + r.warnWord + "”（可能是重掷代币不足）");
                continue;
            }
            if (r.isResult()) {
                idle = 0;
                String sig = r.statSignature();
                if (sig.equals(lastSig)) stable++; else { lastSig = sig; stable = 1; }
                long since = System.currentTimeMillis() - actionAt;
                boolean fresh = !sig.equals(prevSig) || since > 6000;
                if (stable < 2 || since < 1300 || !fresh) { sleepMs(350); continue; }

                Verdict v = RuleEngine.evaluate(r, rule);
                if (v.kind == Verdict.Kind.KEEP) {
                    kept++;
                    log("保留 ✔ " + r.statSummary() + "（" + v.reason + "）");
                    tapLine(r.btnBack);
                    sleepMs(1000);
                    return;
                }
                if (v.kind == Verdict.Kind.REJECT) {
                    rolls++;
                    prevSig = sig;
                    if (rolls % 10 == 1) log("重掷#" + rolls + " 淘汰：" + v.reason + "｜" + r.statSummary());
                    if (maxRolls > 0 && rolls >= maxRolls) throw new StopEx("已完成：达到最大重掷次数 " + maxRolls);
                    tapLine(r.btnContinue);
                    actionAt = System.currentTimeMillis();
                    lastSig = "";
                    stable = 0;
                    unknownRetry = 0;
                    sleepMs(700);
                    continue;
                }
                // UNKNOWN：多读两次，还不行就暂停，绝不乱丢装备
                unknownRetry++;
                if (unknownRetry <= 2) { stable = 1; sleepMs(600); continue; }
                log("无法确定：" + v.reason + "｜" + r.statSummary());
                pauseFor("无法确定这件装备：" + v.reason + "。请肉眼判断后手动处理，再点“继续”");
                unknownRetry = 0;
                lastSig = "";
                stable = 0;
            } else if (r.isConfirm()) {
                idle = 0;
                tapLine(r.btnReroll);
                actionAt = System.currentTimeMillis();
                lastSig = "";
                stable = 0;
                sleepMs(800);
            } else {
                idle++;
                sleepMs(500);
                if (idle > 24) {
                    pauseFor("等了12秒还没出现重掷结果，请点“测试”查看识别情况");
                    idle = 0;
                }
            }
        }
    }
}
