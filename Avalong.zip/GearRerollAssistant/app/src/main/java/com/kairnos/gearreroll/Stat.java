package com.kairnos.gearreroll;

/** 游戏里的14种词条（主词条与副词条共用同一套编号）。 */
public enum Stat {
    HP_FLAT("固定生命值"),
    MELEE_FLAT("固定近战伤害"),
    RANGED_FLAT("固定远程伤害"),
    HP_PCT("生命值%"),
    MELEE_PCT("近战伤害%"),
    RANGED_PCT("远程伤害%"),
    CRIT_CHANCE("暴击机会"),
    CRIT_DMG("暴击伤害"),
    COOLDOWN("冷却(准备时间)"),
    AGILITY("敏捷"),
    CHARISMA("魅力"),
    VALOR("勇气"),
    RANGE("射程"),
    COST("成本(减费)");

    public enum Slot { CUP, KNIFE, WATCH, BOOK }

    public final String label;

    Stat(String label) { this.label = label; }

    public int bit() { return 1 << ordinal(); }

    public boolean isMelee() { return this == MELEE_FLAT || this == MELEE_PCT; }

    public boolean isRanged() { return this == RANGED_FLAT || this == RANGED_PCT; }

    /** 作为主词条出现时，该装备属于哪个部位。 */
    public Slot slotAsMain() {
        switch (this) {
            case HP_FLAT: return Slot.CUP;
            case MELEE_FLAT:
            case RANGED_FLAT: return Slot.KNIFE;
            case AGILITY:
            case COOLDOWN: return Slot.WATCH;
            default: return Slot.BOOK;
        }
    }

    public static int mask(Stat... list) {
        int m = 0;
        for (Stat s : list) m |= s.bit();
        return m;
    }

    public static String names(int mask) {
        StringBuilder sb = new StringBuilder();
        for (Stat s : values()) {
            if ((mask & s.bit()) != 0) {
                if (sb.length() > 0) sb.append("、");
                sb.append(s.label);
            }
        }
        return sb.length() == 0 ? "无" : sb.toString();
    }
}
