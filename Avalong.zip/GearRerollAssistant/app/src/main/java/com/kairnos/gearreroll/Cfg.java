package com.kairnos.gearreroll;

import android.content.Context;
import android.content.SharedPreferences;

/** 所有设置的读写。界面和后台服务共用同一份。 */
public final class Cfg {
    private Cfg() {}

    private static final String PREF = "avalon_settings";

    public static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    // ---- 目标游戏 / 套装 ----
    public static String targetPackage(Context c) { return sp(c).getString("target_pkg", ""); }
    public static void setTargetPackage(Context c, String p) { sp(c).edit().putString("target_pkg", p).apply(); }

    public static int setIndex(Context c) {
        int def = 0;
        for (int i = 0; i < GearData.SETS.length; i++) if (GearData.SETS[i].zh.equals("幸运儿")) def = i;
        int v = sp(c).getInt("set_idx", def);
        return (v < 0 || v >= GearData.SETS.length) ? def : v;
    }
    public static void setSetIndex(Context c, int i) { sp(c).edit().putInt("set_idx", i).apply(); }

    // ---- 筛选规则（每个套装各存一份）----
    public static RuleConfig loadRule(Context c, int idx) {
        RuleConfig r = GearData.defaultRule(GearData.SETS[idx]);
        SharedPreferences p = sp(c);
        String k = "r" + idx + "_";
        if (p.contains(k + "wanted")) {
            r.wanted = p.getInt(k + "wanted", r.wanted);
            r.must = p.getInt(k + "must", r.must);
            r.minHits = p.getInt(k + "minhits", r.minHits);
            r.rejectDuplicate = p.getBoolean(k + "dup", r.rejectDuplicate);
            r.exclusiveMeleeRanged = p.getBoolean(k + "excl", r.exclusiveMeleeRanged);
            r.watchMain = p.getInt(k + "watch", r.watchMain);
            r.bookMain = p.getInt(k + "book", r.bookMain);
            r.knifeMain = p.getInt(k + "knife", r.knifeMain);
        }
        r.qualityMode = p.getInt(k + "quality", r.qualityMode);
        return r;
    }

    public static void saveRule(Context c, int idx, RuleConfig r) {
        String k = "r" + idx + "_";
        sp(c).edit()
            .putInt(k + "wanted", r.wanted).putInt(k + "must", r.must).putInt(k + "minhits", r.minHits)
            .putBoolean(k + "dup", r.rejectDuplicate).putBoolean(k + "excl", r.exclusiveMeleeRanged)
            .putInt(k + "watch", r.watchMain).putInt(k + "book", r.bookMain).putInt(k + "knife", r.knifeMain)
            .putInt(k + "quality", r.qualityMode)
            .apply();
    }

    public static void resetRule(Context c, int idx) {
        String k = "r" + idx + "_";
        sp(c).edit().remove(k + "wanted").remove(k + "must").remove(k + "minhits").remove(k + "dup")
            .remove(k + "excl").remove(k + "watch").remove(k + "book").remove(k + "knife").remove(k + "quality").apply();
    }

    // ---- 运行参数 ----
    public static int columns(Context c) { return Math.max(1, sp(c).getInt("columns", 4)); }
    public static int rows(Context c) { return Math.max(1, sp(c).getInt("rows", 3)); }
    public static boolean autoScroll(Context c) { return sp(c).getBoolean("auto_scroll", true); }
    public static int maxRolls(Context c) { return Math.max(0, sp(c).getInt("max_rolls", 0)); }
    public static boolean safeAck(Context c) { return sp(c).getBoolean("safe_ack", false); }
    public static boolean verifySet(Context c) { return sp(c).getBoolean("verify_set", false); }
    public static int scrollPct(Context c) { return Math.max(30, Math.min(200, sp(c).getInt("scroll_pct", 100))); }

    public static void putInt(Context c, String key, int v) { sp(c).edit().putInt(key, v).apply(); }
    public static void putBool(Context c, String key, boolean v) { sp(c).edit().putBoolean(key, v).apply(); }

    // ---- 校准（屏幕宽高的比例，0~1）----
    public static boolean calibrated(Context c) { return sp(c).getFloat("roll_fx", -1f) >= 0f && sp(c).getFloat("grid_dx", -1f) > 0f; }

    public static void saveCalibration(Context c, float rollX, float rollY, float gridX, float gridY, float dx, float dy) {
        sp(c).edit().putFloat("roll_fx", rollX).putFloat("roll_fy", rollY)
            .putFloat("grid_fx", gridX).putFloat("grid_fy", gridY)
            .putFloat("grid_dx", dx).putFloat("grid_dy", dy).apply();
    }

    public static float f(Context c, String key) { return sp(c).getFloat(key, -1f); }
}
